import Background from '@/assets/login2.png';
import Vistory from '@/assets/victory.svg';
// Removed NewLogo and wave2 imports
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@radix-ui/react-tabs';
import { useState } from 'react';

const Auth = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");

    const handleLogin = async () => {
        // Lógica de login
    };

    const handleSignup = async () => {
        // Lógica de signup
    };

    return (
        <div className="h-[100vh] w-[100vw] flex items-center justify-center relative bg-[#c9d6ff] bg-gradient-to-r from-[#e2e2e2] to-[#c9d6ff]">
            {/* Removed logo images */}
            <div className="h-[80vh] bg-white border-2 border-white shadow-2xl w-[80vw] md:w-[90vw] lg:w-[70vw] xl:w-[60vw] rounded-3xl grid xl:grid-cols-2 relative z-10">
                <div className="flex flex-col gap-10 items-center justify-center">
                    <div className="flex items-center justify-center flex-col">
                        <div className="flex items-center justify-center">
                            <h1 className="text-5xl font-bold md:text-6xl">Bienvenido</h1>
                            <img src={Vistory} alt="Victory Emoji" className='h-[100px]' />
                        </div>
                        <p className='font-medium text-center'>
                            Ingrese las credenciales para usar CcobChat
                        </p>
                    </div>
                    <div className='flex items-center justify-center w-full'>
                        <Tabs className='w-3/4'>
                            <TabsList className='bg-transparent rounded-none flex w-full'>
                                <TabsTrigger value='login'
                                    className="data-[state=active]:bg-transparent text-black text-opacity-90 border-b-2 rounded-none flex-1 min-w-[250px] data-[state=active]:text-black data-[state=active]:font-semibold data-[state=active]:border-b-blue-500 p-3 transition-all duration-300"
                                >Login</TabsTrigger>
                                <TabsTrigger value='signup'
                                    className="data-[state=active]:bg-transparent text-black text-opacity-90 border-b-2 rounded-none flex-1 min-w-[250px] data-[state=active]:text-black data-[state=active]:font-semibold data-[state=active]:border-b-blue-500 p-3 transition-all duration-300"
                                >
                                    Signup
                                </TabsTrigger>
                            </TabsList>
                            <TabsContent className='flex flex-col gap-5 mt-10' value='login'>
                                <input
                                    placeholder='Email'
                                    type='email'
                                    className='rounded-full p-3 w-[500px]'
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                />
                                <input
                                    placeholder='Password'
                                    type='password'
                                    className='rounded-full p-3 w-[500px]'
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                />
                                <Button className="rounded-full p-6" onClick={handleLogin}>Login</Button>
                            </TabsContent>
                            <TabsContent className='flex flex-col gap-5' value='signup'>
                                <input
                                    placeholder='Email'
                                    type='email'
                                    className='rounded-full p-3 w-[500px]'
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                />
                                <input
                                    placeholder='Password'
                                    type='password'
                                    className='rounded-full p-3 w-[500px]'
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                />
                                <input
                                    placeholder='Confirm Password'
                                    type='password'
                                    className='rounded-full p-3 w-[500px]'
                                    value={confirmPassword}
                                    onChange={(e) => setConfirmPassword(e.target.value)}
                                />
                                <Button className="rounded-full p-6" onClick={handleSignup}>Signup</Button>
                            </TabsContent>
                        </Tabs>
                    </div>
                </div>
                <div className='hidden xl:flex justify-center items-center'>
                    <img src={Background} alt="Background" className='h-[511px]' />
                </div>
            </div>
        </div>
    );
}

export default Auth;
