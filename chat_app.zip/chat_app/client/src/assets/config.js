const mongoose = require('mongoose');

const dbConnection = async () => {
    try {
        const uri = process.env.DB_CNN_STRING;
        
        await mongoose.connect(uri);

        console.log('DB Online');
    } catch (error) {
        console.error(error);
        throw new Error('Error a la hora de inicializar la base de datos');
    }
};

module.exports = {
    dbConnection
};
