import { MongoClient } from 'mongodb';

const uri = 'mongodb+srv://amesino:PkU1rWD4vo6pmWVv@base.3s7i4of.mongodb.net/?retryWrites=true&w=majority&appName=base';

async function connect() {
  const client = new MongoClient(uri, {
    tlsAllowInvalidCertificates: true
  });

  try {
    await client.connect();
    console.log('Connected to MongoDB Atlas');
  } catch (err) {
    console.error('Connection failed', err);
  } finally {
    await client.close();
  }
}

connect();
